package LoginCheckedController;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public LoginController() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        HttpSession session = request.getSession();  
       
        if (session != null) {
            session.invalidate();
            session = request.getSession(true);  
        }

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college_management", "root", "Dynamic");
            String query = "SELECT username, password, role, department FROM users WHERE username=? AND password=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String role = rs.getString("role");
                String department = rs.getString("department");

               
                session.setAttribute("username", username);
                session.setAttribute("role", role);
                session.setAttribute("department", department);

                if ("principal".equalsIgnoreCase(role)) {
                    RequestDispatcher rd = request.getRequestDispatcher("/Dashboard/PrincipalDashboard.jsp");
                    rd.forward(request, response);

                } else if ("admin".equalsIgnoreCase(role)) {
                    request.setAttribute("department", department);  
                    RequestDispatcher rd = request.getRequestDispatcher("/Dashboard/Department.jsp");
                    rd.forward(request, response);

                } else {
                    handleStudentLogin(username, password, department, request, response);
                }
            } else {
                request.setAttribute("error", "Invalid Username or Password");
                RequestDispatcher rd = request.getRequestDispatcher("/login/login.jsp");
                rd.include(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handleStudentLogin(String username, String password, String department, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection studentCon = null;
        HttpSession session = request.getSession();
        try {
            switch (department) {
                case "mechanical":
                    studentCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/mechanical_db", "root", "Dynamic");
                    break;
                case "it":
                    studentCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/it_db", "root", "Dynamic");
                    break;
                case "civil":
                    studentCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/civil_db", "root", "Dynamic");
                    break;
                case "electrical":
                    studentCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/electrical_db", "root", "Dynamic");
                    break;
            }

            if (studentCon != null) {
                String studentQuery = "SELECT * FROM data WHERE username=? AND password=?";
                PreparedStatement ps = studentCon.prepareStatement(studentQuery);
                ps.setString(1, username);
                ps.setString(2, password);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    session.setAttribute("studentData", rs);  
                    RequestDispatcher rd = request.getRequestDispatcher("/Dashboard/student.jsp");
                    rd.forward(request, response);
                } else {
                    request.setAttribute("error", "Invalid Student Username or Password");
                    RequestDispatcher rd = request.getRequestDispatcher("/login/login.jsp");
                    rd.include(request, response);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
